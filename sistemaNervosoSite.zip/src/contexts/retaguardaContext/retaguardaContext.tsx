import React from 'react';

export type IUserRetaguarda = {
   operator_id: string;
   user_name:string;
   permissions: string[];
 } | undefined;

type ContextRetaguarda = [
   IUserRetaguarda, React.Dispatch<React.SetStateAction<IUserRetaguarda>>
] | []

export const RetaguardaUserContext = React.createContext<ContextRetaguarda>([]);