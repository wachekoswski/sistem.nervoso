import './loading.css';
import { motion } from 'framer-motion';

export type LoadingType = {
   status: boolean;
   frase?:string;
}

const Loading = ({status,frase}:LoadingType) =>
{
   return(
      <>
      {
      status && 
         <motion.div className="loading_container"
         >
            <div className='loading_body'>
               <div className="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
               { frase && <p className='loading_frase'>{frase}</p> }
            </div>
         </motion.div>
      }
      </>
   )
}

export default Loading;