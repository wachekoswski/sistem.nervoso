import React from 'react';
import { Routes, Route } from 'react-router-dom';

import './App.css';
import Home from './pages/home';
import Curiosity1 from './pages/curiosity1';
import Curiosity2 from './pages/curiosity2';
import Curiosity3 from './pages/curiosity3';
import Curiosity4 from './pages/curiosity4';

function App()
{
   return (
      <Routes>
         <Route index={true} element={<Home/>} />
         <Route
            path='/curiosidades/neuroplasticidade'
            element={<Curiosity1 />}
         />
         <Route
            path='/curiosidades/velocidadeTransmissaoImpulso'
            element={<Curiosity2 />}
         />
         <Route
            path='/curiosidades/neurogenese'
            element={<Curiosity3 />}
         />
         <Route
            path='/curiosidades/conexoesSinapticas'
            element={<Curiosity4 />}
         />
      </Routes>
   );
}

export default App;
