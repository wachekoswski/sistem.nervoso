import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';

import BackgroundBboy from '../assets/svgs/brain_2.svg';
import BboyBack from '../assets/svgs/brain_2.svg';
import BackgroundFormation from '../assets/svgs/brain_2.svg';

import Spark1 from '../assets/svgs/spark_1.svg';
import Spark2 from '../assets/svgs/spark_2.svg';
import Spark3 from '../assets/svgs/spark_3.svg';
import Diamond1 from '../assets/svgs/diamond_1.svg';
import Disk1 from '../assets/svgs/brain_2.svg';
import Disk2 from '../assets/svgs/brain.svg';
import Disk3 from '../assets/svgs/disk_3.svg';
import Schema from '../assets/imgs/snc_central-removebg-preview.png';

import { AnimatePresence, motion } from 'framer-motion';
import { isMobile } from '../components/functions/isMobile';
import Loading from '../components/loading/loading';

const Home = () =>
{

   const [showAllEvents, setShowAllEvents] = React.useState(false);
   const [loading, setLoading] = React.useState(true);

   return (
      <>
      <AnimatePresence>
         <Loading {...{status: loading, frase: "Carregando"}} />
      </AnimatePresence>
         <section className="page page_1">
            <motion.div
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               exit={{ y: '20vh', opacity: 0 }}  // Quando sair, vai para a direita e desaparece
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.2,
               }}
            >
               <img className='image_page1' src={BackgroundBboy} alt="Imagem do Atleta Marlon em posição de Dança" onLoad={() => setLoading(false)} fetchPriority='high' /> 
               <h1>NERVOSO</h1>
               <h2>SISTEMA</h2>
            </motion.div>
            <div>
               <h3>REDE COMPLEXA DE</h3>
               <div className="page__title" style={{ "--stacks": 3, marginBottom: "0", marginTop: "2rem", transform: "scaleY(1.1) scale(.9)", fontSize: "2rem" } as React.CSSProperties} >
                  <span style={{ "--index": 0 } as React.CSSProperties} >CÉLULAS ESPECIALIZADAS:</span>
                  <span style={{ "--index": 1 } as React.CSSProperties} >CÉLULAS ESPECIALIZADAS:</span>
                  <span style={{ "--index": 2 } as React.CSSProperties} >CÉLULAS ESPECIALIZADAS:</span>
               </div>
               <div className="page__title" style={{ "--stacks": 3, marginBottom: "0", marginTop: "2rem", transform: "scaleY(1.1)", fontSize: "2rem" } as React.CSSProperties} >
                  <span style={{ "--index": 0 } as React.CSSProperties} >neurônios</span>
                  <span style={{ "--index": 1 } as React.CSSProperties} >neurônios</span>
                  <span style={{ "--index": 2 } as React.CSSProperties} >neurônios</span>
               </div>
               <h3 style={{marginTop: "0rem"}}>CÉLULAS DA GLIA</h3>
            </div>
		      <div className="mouse"></div>
            <div className="decoration">
               <img src={Spark1} alt="Imagem de enfeite, design"
               />
               <img src={Spark2} alt="Imagem de enfeite, design" />
               <img src={Spark3} alt="Imagem de enfeite, design" />
               <img src={Spark1} alt="Imagem de enfeite, design" style={{display: "none"}} />
               <img src={Spark2} alt="Imagem de enfeite, design" />
            </div>
         </section>
         <section id="page_2" className="page page_2">
            <div className="page__title" style={{ "--stacks": 3 } as React.CSSProperties} >
               <span style={{ "--index": 0 } as React.CSSProperties} >FATOS {isMobile() ? <b style={{fontSize: "2rem"}}>INTERESSANTES</b> : <>INTERESSANTES</>}</span>
               <span style={{ "--index": 1 } as React.CSSProperties} >FATOS {isMobile() ? <b style={{fontSize: "2rem"}}>INTERESSANTES</b> : <>INTERESSANTES</>}</span>
               <span style={{ "--index": 2 } as React.CSSProperties} >FATOS {isMobile() ? <b style={{fontSize: "2rem"}}>INTERESSANTES</b> : <>INTERESSANTES</>}</span>
            </div>
               <div className="box__events_padding" style={{height: "fit-content", paddingBottom: "1rem"}}>
                  <Link to="/curiosidades/neuroplasticidade" style={{ textDecoration: "none", color: "var(--preto)" } as React.CSSProperties} >
                     <motion.div className='events' 
                        initial={{ x: '20vh', opacity: 0 }} 
                        whileInView={{ x: 0, opacity: 1 }}
                        exit={{ x: '20vh', opacity: 0 }}  // Quando sair, vai para a direita e desaparece
                        transition={{
                           type: 'spring',
                           stiffness: 150,
                           damping: 20,
                           delay: 0.2,
                        }}
                     >
                        <span>1º</span>
                        CAPACIDADE DE ADAPTAÇÃO
                        <span>NEUROPLASTICIDADE</span>
                     </motion.div>
                  </Link>
                  <Link to="/curiosidades/velocidadeTransmissaoImpulso" style={{ textDecoration: "none", color: "var(--preto)" } as React.CSSProperties} > 
                     <motion.div className='events' 
                        initial={{ x: '20vh', opacity: 0 }} 
                        whileInView={{ x: 0, opacity: 1 }}
                        transition={{
                           type: 'spring',
                           stiffness: 150,
                           damping: 20,
                           delay: 0.2,
                        }}
                     >
                        <span>2º</span>
                        VELOCIDADE DE TRANSMISSÃO DE IMPULSO
                        <span>430Km/h</span>
                     </motion.div>
                  </Link>
               </div>
               <div className="box__events_padding" style={{height: "fit-content", paddingBottom: "1rem"}}>
                  <Link to="/curiosidades/neurogenese" style={{ textDecoration: "none", color: "var(--preto)" } as React.CSSProperties} >
                     <motion.div className='events' 
                        initial={{ x: '20vh', opacity: 0 }} 
                        whileInView={{ x: 0, opacity: 1 }}
                        exit={{ x: '20vh', opacity: 0 }}  // Quando sair, vai para a direita e desaparece
                        transition={{
                           type: 'spring',
                           stiffness: 150,
                           damping: 20,
                           delay: 0.2,
                        }}
                     >
                        <span>3º</span>
                        NEUROGÊNESE
                        <span>NEURÔRIOS NOVINHOS ;)</span>
                     </motion.div>
                  </Link>
                  <Link to="/curiosidades/conexoesSinapticas" style={{ textDecoration: "none", color: "var(--preto)" } as React.CSSProperties} >
                     <motion.div className='events' 
                        initial={{ x: '20vh', opacity: 0 }} 
                        whileInView={{ x: 0, opacity: 1 }}
                        transition={{
                           type: 'spring',
                           stiffness: 150,
                           damping: 20,
                           delay: 0.2,
                        }}
                     >
                        <span>4º</span>
                        10 MIL CONEXÕES SINÁPTICAS
                        <span>Bastante?</span>
                     </motion.div>
                  </Link>
                  <Link to="/curiosidades/conexoesSinapticas" style={{ textDecoration: "none", color: "var(--preto)" } as React.CSSProperties} >
                     <motion.div className='events' 
                        initial={{ x: '20vh', opacity: 0 }} 
                        whileInView={{ x: 0, opacity: 1 }}
                        transition={{
                           type: 'spring',
                           stiffness: 150,
                           damping: 20,
                           delay: 0.2,
                        }}
                     >
                        <span>5º</span>
                        86 BILHÕES DE NEURÔNIOS
                        <span>SÓ ISSO?</span>
                     </motion.div>
                  </Link>
               </div>
            <img src={BboyBack} alt="Imagem do Atleta Marlon com a mão erguida" />
		      <div className="mouse"></div>
         </section>
         <section className="page page_3">
            <div className="page__title" style={{ "--stacks": 3 } as React.CSSProperties} >
               <span style={{ "--index": 0 } as React.CSSProperties} >EMOÇÕES E {isMobile() ? <b style={{fontSize: "1.5rem"}}>NEUROTRANSMISSORES</b> : <>NEUROTRANSMISSORES</>}</span>
               <span style={{ "--index": 1 } as React.CSSProperties} >EMOÇÕES E {isMobile() ? <b style={{fontSize: "1.5rem"}}>NEUROTRANSMISSORES</b> : <>NEUROTRANSMISSORES</>}</span>
               <span style={{ "--index": 2 } as React.CSSProperties} >EMOÇÕES E {isMobile() ? <b style={{fontSize: "1.5rem"}}>NEUROTRANSMISSORES</b> : <>NEUROTRANSMISSORES</>}</span>
            </div>
            <ul>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
                  DOPAMINA
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
                  SEROTONINA
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
                  ACETILCOLINA
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
                  Ácido Gama-Aminobutírico
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
                  GLUTAMATO
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
                  Noradrenalina
               </motion.li>
            </ul>
            <img src={BackgroundFormation} alt="Imagem de Fundo Simbolizando Formação Musical, uma fita cassete" />
		      <div className="mouse"></div>
            <div className="decoration">
               <img src={Diamond1} alt="Imagem de enfeite, design" />
            </div>
         </section>
         <section className="page page_4">
            <div className="page__title" style={{ "--stacks": 3 } as React.CSSProperties} >
               <span style={{ "--index": 0 } as React.CSSProperties} >DIVISÕES</span>
               <span style={{ "--index": 1 } as React.CSSProperties} >DIVISÕES</span>
               <span style={{ "--index": 2 } as React.CSSProperties} >DIVISÕES</span>
            </div>
            <div>
               <motion.img 
                  style={{filter: "drop-shadow(0px 0px 0.2px white) grayscale(1)", mixBlendMode: "hue", width: "100%"}}
                  src={Schema} alt="Imagem de enfeite, design" 
               />
            </div>
		      <div className="mouse"></div>
         </section>
         <section className="page">
            <div className="page__title" style={{ "--stacks": 3 } as React.CSSProperties} >
               <span style={{ "--index": 0 } as React.CSSProperties} >DEVELOPED BY</span>
               <span style={{ "--index": 1 } as React.CSSProperties} >DEVELOPED BY</span>
               <span style={{ "--index": 2 } as React.CSSProperties} >DEVELOPED BY</span>
            </div>
            <div className="page_5" >
               <motion.a href="https://www.instagram.com/giongodesign/" target='_blank' rel='noreferrer' style={{paddingInline: "2rem"}}  
                  initial={{ scale: .1, opacity: 0 }} 
                  whileInView={{ scale: 1, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
               >
               </motion.a>
               <motion.p
                  initial={{ y: "-10vh", opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 250,
                     damping: 20,
                     delay: .5,
                  }}
               >
                  @wachekoswski2.0
               </motion.p>
               <div className="decoration">
                  <img src={Disk3} alt="Imagem de enfeite, design" />
               </div>
            </div>
            <p>{new Date().getFullYear()} ® Todos os direitos Resevados</p>
         </section>
      </>
   );
};

export default Home;