import React from 'react';

import BboyBack from '../assets/svgs/brain.svg';

import { motion } from 'framer-motion';
import { HashLink } from 'react-router-hash-link';

function Curiosity3()
{

   return (
      <section className="page page_3" style={{overflowY: "scroll"}}>
         <div className="page__title" style={{ "--stacks": 3, marginBottom: "0rem" } as React.CSSProperties} >
            <span style={{ "--index": 0 } as React.CSSProperties} >Neurogênese</span>
            <span style={{ "--index": 1 } as React.CSSProperties} >Neurogênese</span>
            <span style={{ "--index": 2 } as React.CSSProperties} >Neurogênese</span>
         </div>
         <div className="page__title animate__animated animate__fadeInDown animate__delay-1s" style={{ "--stacks": 3, color: "silver" } as React.CSSProperties} >
            <span style={{ "--index": 0 } as React.CSSProperties} >O Surgimento de Novos Neurônios</span>
            <span style={{ "--index": 1 } as React.CSSProperties} >O Surgimento de Novos Neurônios</span>
            <span style={{ "--index": 2 } as React.CSSProperties} >O Surgimento de Novos Neurônios</span>
         </div>
         <ul style={{width: "80%"}}>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.2,
               }}
               style={{textAlign: "justify"}}
            >
               A descoberta da neurogênese desafiou a antiga crença de que o número de neurônios no cérebro era fixo após o nascimento. Hoje sabemos que novos neurônios são gerados principalmente em duas áreas:
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.24,
               }}
            >
               Hipocampo: Essencial para memória e aprendizado, essa região se beneficia da neurogênese em tarefas como a retenção de novas informações e a navegação espacial.
Zona subventricular: Localizada ao longo das paredes dos ventrículos laterais, ela contribui para a regeneração de neurônios no sistema olfatório.
A neurogênese é influenciada por diversos fatores:
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Fatores positivos: Exercício físico, aprendizagem, dieta rica em antioxidantes e ácidos graxos ômega-3.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Fatores negativos: Estresse crônico, privação de sono e exposição a toxinas.
            </motion.li>
         </ul>
         <img src={BboyBack} alt="Cerebro" />
         <HashLink to="/#page_2" className='btn'>VOLTAR</HashLink>
      </section>
   );
}

export default Curiosity3;
