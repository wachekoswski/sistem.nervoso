import React from 'react';

import BboyBack from '../assets/svgs/spark_2.svg';

import { motion } from 'framer-motion';
import { HashLink } from 'react-router-hash-link';

function Curiosity2()
{

   return (
      <section className="page page_3" style={{overflowY: "scroll"}}>
         <div className="page__title" style={{ "--stacks": 3, marginBottom: "0rem" } as React.CSSProperties} >
            <span style={{ "--index": 0 } as React.CSSProperties} >VELOCIDADE DE TRANSMISSÃO</span>
            <span style={{ "--index": 1 } as React.CSSProperties} >VELOCIDADE DE TRANSMISSÃO</span>
            <span style={{ "--index": 2 } as React.CSSProperties} >VELOCIDADE DE TRANSMISSÃO</span>
         </div>
         <div className="page__title animate__animated animate__lightSpeedInLeft animate__delay-1s" style={{ "--stacks": 3, color: "silver" } as React.CSSProperties} >
            <span style={{ "--index": 0 } as React.CSSProperties} >do Impulso Nervoso</span>
            <span style={{ "--index": 1 } as React.CSSProperties} >do Impulso Nervoso</span>
            <span style={{ "--index": 2 } as React.CSSProperties} >do Impulso Nervoso</span>
         </div>
         <ul style={{width: "80%"}}>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.2,
               }}
               style={{textAlign: "justify"}}
            >
               O sistema nervoso humano opera com uma eficiência impressionante, enviando sinais através de impulsos elétricos chamados potenciais de ação. Esses sinais viajam ao longo dos axônios, cuja velocidade pode variar de 0,5 m/s a 120 m/s, dependendo de dois fatores principais:
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Presença de bainha de mielina: A mielina isola os axônios e permite uma condução saltatória, onde o impulso "salta" de um nódulo de Ranvier para outro, acelerando a transmissão.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Diâmetro do axônio: Axônios mais largos conduzem impulsos mais rapidamente.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.24,
               }}
            >
               Essa alta velocidade é essencial para reações rápidas, como os reflexos espinhais, que evitam danos corporais ao responder rapidamente a estímulos dolorosos, sem necessidade de processamento inicial pelo cérebro.
            </motion.li>
         </ul>
         <img src={BboyBack} alt="Cerebro" />
         <HashLink to="/#page_2" className='btn'>VOLTAR</HashLink>
      </section>
   );
}

export default Curiosity2;
