import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';

import BboyBack from '../assets/svgs/brain_2.svg';

import { HashLink } from 'react-router-hash-link';

import { motion } from 'framer-motion';

function Curiosity1()
{

   return (
      <>
         <section className="page page_3" style={{overflowY: "scroll"}}>
            <div className="page__title" style={{ "--stacks": 3, marginBottom: "0rem" } as React.CSSProperties} >
               <span style={{ "--index": 0 } as React.CSSProperties} >NEUROPLASTICIDADE</span>
               <span style={{ "--index": 1 } as React.CSSProperties} >NEUROPLASTICIDADE</span>
               <span style={{ "--index": 2 } as React.CSSProperties} >NEUROPLASTICIDADE</span>
            </div>
            <div className="page__title animate__animated animate__rubberBand animate__repeat-3 animate__delay-1s" style={{ "--stacks": 3, color: "silver" } as React.CSSProperties} >
               <span style={{ "--index": 0 } as React.CSSProperties} >Capacidade de Transformação</span>
               <span style={{ "--index": 1 } as React.CSSProperties} >Capacidade de Transformação</span>
               <span style={{ "--index": 2 } as React.CSSProperties} >Capacidade de Transformação</span>
            </div>
            <ul style={{width: "80%"}}>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.2,
                  }}
                  style={{textAlign: "justify"}}
               >
                  A neuroplasticidade é a capacidade do sistema nervoso de se adaptar, mudar e se reorganizar ao longo da vida, tanto em nível funcional quanto estrutural. Essa transformação ocorre em resposta a diferentes estímulos, como aprendizado, experiências, traumas ou doenças neurológicas. A neuroplasticidade é dividida em dois tipos principais:
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.3,
                  }}
                  style={{textAlign: "justify", marginLeft: "5rem"}}
               >
                  Neuroplasticidade funcional: Envolve a redistribuição de funções de áreas danificadas do cérebro para áreas saudáveis. Por exemplo, após um acidente vascular cerebral (AVC), outras regiões podem assumir funções motoras perdidas.
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.3,
                  }}
                  style={{textAlign: "justify", marginLeft: "5rem"}}
               >
                  Neuroplasticidade estrutural: Diz respeito a mudanças na arquitetura física do cérebro, como o crescimento de novas conexões sinápticas e o fortalecimento ou enfraquecimento das já existentes.
               </motion.li>
               <motion.li
                  initial={{ y: '20vh', opacity: 0 }} 
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{
                     type: 'spring',
                     stiffness: 150,
                     damping: 20,
                     delay: 0.24,
                  }}
               >
                  Além disso, a neuroplasticidade está envolvida em processos de aprendizado contínuo, como o domínio de uma nova língua ou habilidade, e em estratégias de reabilitação, como a terapia cognitiva e o treinamento físico para recuperação motora.
               </motion.li>
            </ul>
            <img src={BboyBack} alt="Cerebro" />
            <HashLink to="/#page_2" className='btn'>VOLTAR</HashLink>
         </section>
      </>
   );
}

export default Curiosity1;
