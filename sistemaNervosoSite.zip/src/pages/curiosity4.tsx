import React from 'react';

import BboyBack from '../assets/svgs/brain_2.svg';

import { motion } from 'framer-motion';
import { HashLink } from 'react-router-hash-link';

function Curiosity4()
{

   return (
      <section className="page page_3" style={{overflowY: "scroll"}}>
         <div className="page__title" style={{ "--stacks": 3, marginBottom: "0rem" } as React.CSSProperties} >
            <span style={{ "--index": 0 } as React.CSSProperties} >A Conexão Incrível</span>
            <span style={{ "--index": 1 } as React.CSSProperties} >A Conexão Incrível</span>
            <span style={{ "--index": 2 } as React.CSSProperties} >A Conexão Incrível</span>
         </div>
         <div className="page__title animate__animated animate__pulse animate__infinite" style={{ "--stacks": 3, color: "silver" } as React.CSSProperties} >
            <span style={{ "--index": 0 } as React.CSSProperties} >10 Mil Sinapses por Neurônio</span>
            <span style={{ "--index": 1 } as React.CSSProperties} >10 Mil Sinapses por Neurônio</span>
            <span style={{ "--index": 2 } as React.CSSProperties} >10 Mil Sinapses por Neurônio</span>
         </div>
         <ul style={{width: "80%"}}>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.2,
               }}
               style={{textAlign: "justify"}}
            >
               O cérebro humano é um dos sistemas mais complexos da natureza. <b style={{color: "var(--cor-400)"}}>Com cerca de 86 bilhões de neurônios</b>, cada um podendo formar até 10 mil sinapses, as conexões entre eles permitem uma infinidade de combinações e interações. Essa rede complexa é responsável por:
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Processamento de informações sensoriais.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Armazenamento e recuperação de memórias.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Execução de tarefas motoras.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{textAlign: "justify", marginLeft: "5rem"}}
            >
               Regulação de emoções.
            </motion.li>
            <motion.li
               initial={{ y: '20vh', opacity: 0 }} 
               whileInView={{ y: 0, opacity: 1 }}
               transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.3,
               }}
               style={{marginTop: "3rem"}}
            >
               A força dessas sinapses pode mudar com o tempo por meio de processos como a potenciação de longo prazo (LTP), que fortalece conexões frequentemente usadas, e a depressão de longo prazo (LTD), que enfraquece conexões pouco utilizadas. Isso torna o cérebro altamente adaptável e eficiente.
            </motion.li>
         </ul>
         <img src={BboyBack} alt="Cerebro" />
         <HashLink to="/#page_2" className='btn'>VOLTAR</HashLink>
      </section>
   );
}

export default Curiosity4;
